export interface Pair {
  _id: string;
  address: string;
  symbol1: string;
  symbol2: string;
  chain: number;
  factory: string;
}